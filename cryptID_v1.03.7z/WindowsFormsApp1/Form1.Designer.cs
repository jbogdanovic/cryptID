﻿namespace cryptID
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.userinput = new System.Windows.Forms.RichTextBox();
            this.InstructionsText = new System.Windows.Forms.RichTextBox();
            this.Clear_Button = new System.Windows.Forms.Button();
            this.History_Button = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.Help_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(35, 331);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 45);
            this.button1.TabIndex = 1;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // userinput
            // 
            this.userinput.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userinput.Location = new System.Drawing.Point(35, 131);
            this.userinput.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.userinput.MaxLength = 500;
            this.userinput.Name = "userinput";
            this.userinput.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.userinput.Size = new System.Drawing.Size(761, 182);
            this.userinput.TabIndex = 2;
            this.userinput.Text = "";
            this.userinput.Click += new System.EventHandler(this.userinput_Click);
            // 
            // InstructionsText
            // 
            this.InstructionsText.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.InstructionsText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.InstructionsText.ForeColor = System.Drawing.SystemColors.MenuText;
            this.InstructionsText.Location = new System.Drawing.Point(35, 32);
            this.InstructionsText.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.InstructionsText.Name = "InstructionsText";
            this.InstructionsText.ReadOnly = true;
            this.InstructionsText.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.InstructionsText.Size = new System.Drawing.Size(761, 82);
            this.InstructionsText.TabIndex = 3;
            this.InstructionsText.Text = "CryptID is used to identify hash types. Over 10 different algorithms are currentl" +
    "y supported, including MD5, SHA256, and SHA512, with more to follow\n";
            // 
            // Clear_Button
            // 
            this.Clear_Button.Location = new System.Drawing.Point(179, 331);
            this.Clear_Button.Name = "Clear_Button";
            this.Clear_Button.Size = new System.Drawing.Size(144, 45);
            this.Clear_Button.TabIndex = 4;
            this.Clear_Button.Text = "Clear";
            this.Clear_Button.UseVisualStyleBackColor = true;
            this.Clear_Button.Click += new System.EventHandler(this.Clear_Button_Click);
            // 
            // History_Button
            // 
            this.History_Button.Location = new System.Drawing.Point(329, 331);
            this.History_Button.Name = "History_Button";
            this.History_Button.Size = new System.Drawing.Size(144, 45);
            this.History_Button.TabIndex = 5;
            this.History_Button.Text = "History\r\n";
            this.History_Button.UseVisualStyleBackColor = true;
            this.History_Button.Click += new System.EventHandler(this.History_Button_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Elephant", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkArea = new System.Windows.Forms.LinkArea(0, 10);
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(30, 396);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(123, 26);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Report bug";
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.White;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Help_Button
            // 
            this.Help_Button.Cursor = System.Windows.Forms.Cursors.Default;
            this.Help_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Help_Button.FlatAppearance.BorderSize = 4;
            this.Help_Button.Location = new System.Drawing.Point(479, 331);
            this.Help_Button.Name = "Help_Button";
            this.Help_Button.Size = new System.Drawing.Size(107, 45);
            this.Help_Button.TabIndex = 7;
            this.Help_Button.Text = "Help";
            this.Help_Button.UseVisualStyleBackColor = true;
            this.Help_Button.Click += new System.EventHandler(this.Help_Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(830, 441);
            this.Controls.Add(this.Help_Button);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.History_Button);
            this.Controls.Add(this.Clear_Button);
            this.Controls.Add(this.InstructionsText);
            this.Controls.Add(this.userinput);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CryptID";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void Userinput_Enter(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox userinput;
        private System.Windows.Forms.RichTextBox InstructionsText;
        private System.Windows.Forms.Button Clear_Button;
        private System.Windows.Forms.Button History_Button;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button Help_Button;
    }
}

