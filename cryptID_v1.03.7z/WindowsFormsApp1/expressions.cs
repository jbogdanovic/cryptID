﻿using System;
using System.Collections.Generic;

public static class datastore
{
    public static Dictionary<string, string> _dict = new Dictionary<string, string>
    {
        {"MD5", "^[a-f0-9]{32}$"},
        {"MD2", "^(\\$md2\\$)?[a-f0-9]{32}$"},
        {"SHA-256", "^[a-f0-9]{64}(:.+)?$"},
        {"SHA-384", "^[a-f0-9]{96}$"},
        {"SHA-1", "^[a-f0-9]{40}(:.+)?$"},
        {"SHA-512", "^[a-f0-9]{128}(:.+)?$"},
        {"crc32", "^(\\$crc32\\$[a-f0-9]{8}.)?[a-f0-9]{8}$"},
        {"RIPEMD-320", "^[a-f0-9]{80}$"},
        {"$nefru-256", "^(\\$snefru\\$)?[a-f0-9]{64}$"},
        {"Adler-32", "^[a-f0-9]{8}$"}
    };
}