﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)// where code will go to eval userinputed hash
        {
        //BELOW IS SIMULATION CODE FOR TESTING OF MD5 HASH
            if(String.IsNullOrEmpty(userinput.Text))
            {
                MessageBox.Show("Please Enter a Hash!", "Results");
            }
            //if not empty check number of digits, MD5 has 32 digits
            if(userinput.Text.Length == 32)
            {
                MessageBox.Show("Hash type is MD5", "Results");// first is message second is title of message box
            }

            if((userinput.Text.Length < 32 || userinput.Text.Length > 32) && (!String.IsNullOrEmpty(userinput.Text)))// just extra test added, just for show
            {
                MessageBox.Show("Unable to ID Hash", "Results");
            }

        }

        private void Form1_Load(object sender, EventArgs e)// function for placeholder in userinput text box
        {
            if (String.IsNullOrEmpty(userinput.Text))
            {
                userinput.Text = "Enter Hash to ID Here..";
                userinput.ForeColor = Color.Gray;
            }
        }

        private void userinput_Click(object sender, EventArgs e)// function to clear placeholder upon user clicking it
        {

            if (!String.IsNullOrEmpty(userinput.Text))
            {
                userinput.Text = "";
            }
        }
    }
}
