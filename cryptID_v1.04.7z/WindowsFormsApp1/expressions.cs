﻿using System;
using System.Collections.Generic;

public static class datastore
{
    public static Dictionary<string, string> _dict = new Dictionary<string, string>
    {
        {"Adler-32", "^[a-f0-9]{8}$"},
        {"Blowfish", "^(\\$2[axy]|\\$2)\\$[0-9]{2}\\$[a-z0-9\\/.]{53}$" },
        {"CRC-16", "^[a-f0-9]{4}$"},
        {"CRC-24", "^[^[a-f0-9]{6}$"},
        {"CRC-32", "^(\\$crc32\\$[a-f0-9]{8}.)?[a-f0-9]{8}$"},
        {"CRC-64", "^[a-f0-9]{16}$" },
        {"LM", "^[a-f0-9]{32}(:.+)?$" },
        {"MD2", "^(\\$md2\\$)?[a-f0-9]{32}$"},
        {"MD5", "^[a-f0-9]{32}$"},
        {"NTLM", "^(\\$NT\\$)?[a-f0-9]{32}$"},
        {"RIPEMD-256", "^[a-f0-9]{64}(:.+)?$"},
        {"RIPEMD-320", "^[a-f0-9]{80}$"},
        {"SHA-1", "^[a-f0-9]{40}(:.+)?$"},
        {"SHA-224", "^[a-f0-9]{56}$"},
        {"SHA-256", "^[a-f0-9]{64}(:.+)?$"},
        {"SHA-384", "^[a-f0-9]{96}$"},
        {"SHA-512", "^[a-f0-9]{128}(:.+)?$"},
        {"Tiger-128", "^[a-f0-9]{32}(:.+)?$" },
        {"Tiger-160", "^[a-f0-9]{40}(:.+)?$" },
        {"Tiger-192", "^[a-f0-9]{48}$" },
        {"$nefru-256", "^(\\$snefru\\$)?[a-f0-9]{64}$"},
    };
}