﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;


namespace cryptID
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {	
			string hash;

            // Read in entered hash
            Validate_Input();
			hash = userinput.Text;
            Retrieve_Matches(hash);
        }

        private void Form1_Load(object sender, EventArgs e)// function for placeholder in userinput text box
        {
            if (String.IsNullOrEmpty(userinput.Text))
            {
                userinput.Text = "Enter Hash to ID Here..";
                userinput.ForeColor = Color.Gray;
            }
        }

        private void userinput_Click(object sender, EventArgs e)// function to clear placeholder upon user clicking it
        {

            if (userinput.Text == "Enter Hash to ID Here..")
            {
                userinput.Text = "";
            }
        }

        private void Retrieve_Matches(string hash)
        {
            userinput.Text = "";
            string result = "";

            //Compares all of the hashes in the dictionary against hash
            foreach (KeyValuePair<string, string> entry in datastore._dict)
            {

                //Casts Value as Regex type
                Regex rgx = new Regex(entry.Value);

                //Checks to see if hash matches regular expression and adds it to result if it does
                if (rgx.IsMatch(hash))
                    result += entry.Key + "\r\n";
            }
            //Either prints results or returns unable to identify depending on results
            if (result == "")
            {
                userinput.Text = "Unable to Identify " + "\"" + hash + "\"";
                Write_History("Unable to Identify " + "\"" + hash + "\"\r\n");

            }
            else
            {
                userinput.Text = "Possible Matches for " + "\""  + hash + "\"\r\n" + result;
                Write_History("Possible Matches for " + "\"" + hash + "\"" + "\r\n" + result + "\r\n");
            }
        }

        private void Write_History(string result)
        {
            string history = @"history.txt";

            //Creates History file if it is nonexistent
            if (!File.Exists(history))
                File.WriteAllText(history, result);
            else
                File.AppendAllText(history, result);

        }

        private void Validate_Input()
        {
            if (String.IsNullOrEmpty(userinput.Text))
            {
                MessageBox.Show("Please Enter a Hash!", "Results");
            }
        }

        private void Clear_Button_Click(object sender, EventArgs e)// function to clear results from text box
        {
            userinput.Text = "";
        }

        private void History_Button_Click(object sender, EventArgs e)
        {
            userinput.Text = "";
            string line;

            if (File.Exists(@"history.txt"))
            {

                StreamReader sr = new StreamReader(@"history.txt");

                //Read History File line by line
                line = sr.ReadLine();
                while (line != null)
                {
                    userinput.AppendText(line + "\r\n");
                    line = sr.ReadLine();
                }
                sr.Close();

                //Automatically scroll to most recent history
                userinput.SelectionStart = userinput.Text.Length;
                userinput.ScrollToCaret();
            }
            else
            {
                userinput.Text = "Currently no History to show";
            }
        }
    }
}
