﻿namespace cryptID
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.userinput = new System.Windows.Forms.RichTextBox();
            this.InstructionsText = new System.Windows.Forms.RichTextBox();
            this.Clear_Button = new System.Windows.Forms.Button();
            this.History_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(35, 283);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 45);
            this.button1.TabIndex = 1;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // userinput
            // 
            this.userinput.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userinput.Location = new System.Drawing.Point(36, 120);
            this.userinput.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.userinput.MaxLength = 500;
            this.userinput.Name = "userinput";
            this.userinput.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.userinput.Size = new System.Drawing.Size(595, 139);
            this.userinput.TabIndex = 2;
            this.userinput.Text = "";
            this.userinput.Click += new System.EventHandler(this.userinput_Click);
            // 
            // InstructionsText
            // 
            this.InstructionsText.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.InstructionsText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.InstructionsText.ForeColor = System.Drawing.SystemColors.MenuText;
            this.InstructionsText.Location = new System.Drawing.Point(35, 32);
            this.InstructionsText.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.InstructionsText.Name = "InstructionsText";
            this.InstructionsText.ReadOnly = true;
            this.InstructionsText.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.InstructionsText.Size = new System.Drawing.Size(596, 82);
            this.InstructionsText.TabIndex = 3;
            this.InstructionsText.Text = "CryptID is used to identify hash types. Over 10 different algorithms are currentl" +
    "y supported, including MD5, SHA256, and SHA512, with more to follow\n\n.";
            // 
            // Clear_Button
            // 
            this.Clear_Button.Location = new System.Drawing.Point(188, 283);
            this.Clear_Button.Name = "Clear_Button";
            this.Clear_Button.Size = new System.Drawing.Size(144, 45);
            this.Clear_Button.TabIndex = 4;
            this.Clear_Button.Text = "Clear";
            this.Clear_Button.UseVisualStyleBackColor = true;
            this.Clear_Button.Click += new System.EventHandler(this.Clear_Button_Click);
            // 
            // History_Button
            // 
            this.History_Button.Location = new System.Drawing.Point(351, 283);
            this.History_Button.Name = "History_Button";
            this.History_Button.Size = new System.Drawing.Size(123, 45);
            this.History_Button.TabIndex = 5;
            this.History_Button.Text = "History\r\n";
            this.History_Button.UseVisualStyleBackColor = true;
            this.History_Button.Click += new System.EventHandler(this.History_Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(661, 361);
            this.Controls.Add(this.History_Button);
            this.Controls.Add(this.Clear_Button);
            this.Controls.Add(this.InstructionsText);
            this.Controls.Add(this.userinput);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CryptID";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        private void Userinput_Enter(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox userinput;
        private System.Windows.Forms.RichTextBox InstructionsText;
        private System.Windows.Forms.Button Clear_Button;
        private System.Windows.Forms.Button History_Button;
    }
}

