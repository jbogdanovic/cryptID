﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;


namespace cryptID
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {	
			string hash;

            // Check to make sure input is valid
            Validate_Input();
            // Read in input
			hash = userinput.Text;
            // Convert to lowercase to work with regular expressions
            hash = hash.ToLower();
            // Return and Print Matches
            Retrieve_Matches(hash);
        }

        private void Form1_Load(object sender, EventArgs e)// function for placeholder in userinput text box
        {
            if (String.IsNullOrEmpty(userinput.Text))
            {
                userinput.Text = "Enter Hash to ID Here..";
                userinput.ForeColor = Color.Gray;
            }
        }

        private void userinput_Click(object sender, EventArgs e)// function to clear placeholder upon user clicking it
        {

            if (userinput.Text == "Enter Hash to ID Here..")
            {
                userinput.Text = "";
            }
        }

        private void Retrieve_Matches(string hash)
        {
            userinput.Text = "";
            string result = "";

            //Compares all of the hashes in the dictionary against hash
            foreach (KeyValuePair<string, string> entry in datastore._dict)
            {

                //Casts Value as Regex type
                Regex rgx = new Regex(entry.Value);

                //Checks to see if hash matches regular expression and adds it to result if it does
                if (rgx.IsMatch(hash))
                    result += entry.Key + "\r\n";
            }
            //Either prints results or returns unable to identify depending on results
            if (result == "")
            {
                userinput.Text = "Unable to Identify " + "\"" + hash + "\"";
                Write_History("Unable to Identify " + "\"" + hash + "\"\r\n");

            }
            else
            {
                userinput.Text = "Possible Matches for " + "\""  + hash + "\"\r\n" + result;
                Write_History("Possible Matches for " + "\"" + hash + "\"" + "\r\n" + result + "\r\n");
            }
        }

        private void Write_History(string result)
        {
            string history = @"history.txt";

            //Creates History file if it is nonexistent
            if (!File.Exists(history))
                File.WriteAllText(history, result);
            else
                File.AppendAllText(history, result);

        }

        private void Validate_Input()
        {
            if (String.IsNullOrEmpty(userinput.Text))
            {
                MessageBox.Show("Please Enter a Hash!", "Results");
            }

            if (userinput.Text.Contains( "\n" ))// tests userinputed string for return
            {
                MessageBox.Show("Invalid Format, Don't Include Return!", "Results" );
            }

            if (userinput.Text.Contains( "\x20"))// tests userinput for space
            {
                MessageBox.Show("Invalid Format, Don't Include Spaces!", "Results" );
            }
        }

        private void Clear_Button_Click(object sender, EventArgs e)// function to clear results from text box
        {
            userinput.Text = "";
        }

        private void History_Button_Click(object sender, EventArgs e)// function that presents submission result history to screen
        {
            userinput.Text = "";
            string line;

            if (File.Exists(@"history.txt"))
            {

                StreamReader sr = new StreamReader(@"history.txt");

                //Read History File line by line
                line = sr.ReadLine();
                while (line != null)
                {
                    userinput.AppendText(line + "\r\n");
                    line = sr.ReadLine();
                }
                sr.Close();

                //Automatically scroll to most recent history
                userinput.SelectionStart = userinput.Text.Length;
                userinput.ScrollToCaret();
            }
            else
            {
                userinput.Text = "Currently no History to show";
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)// function to send user to bug reporting page
        {
            System.Diagnostics.Process.Start("https://github.com/jbogdanovic/cryptID/blob/bug_reporting/bug_report");
        }

        private void Help_Button_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://raw.githubusercontent.com/jbogdanovic/cryptID/master/README.md");
        }

    }
}
