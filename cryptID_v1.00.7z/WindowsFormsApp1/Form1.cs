﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(userinput.Text))
            {
                MessageBox.Show("Please Enter a Hash!", "Results");
            }
			
			int identified = 0;
			string hash, id, pattern;
            string result = "Possible results: \r\n";
	
			// Read in entered hash
			hash = userinput.Text; 
			// Read in the file location 
			System.IO.StreamReader inFile =  new System.IO.StreamReader(@"..\..\expressions.dat");
            // Reads through file containing hashes
			while((id = inFile.ReadLine()) != null)
			{
				// read regex
				pattern = inFile.ReadLine(); 
				Regex rgx = new Regex(pattern);
		
                // If hash matches regular expression, add name of hash to list of results
				if(rgx.IsMatch(hash))
				{
                    result += id += "\r\n";
					identified = 1;
				}
			}

            if (identified == 1)
            {
                userinput.Text = result;
            }
            else if (identified == 0 && !String.IsNullOrEmpty(userinput.Text))
            {
                MessageBox.Show("Unable to identify");
            }
	
			inFile.Close();
        }

        private void Form1_Load(object sender, EventArgs e)// function for placeholder in userinput text box
        {
            if (String.IsNullOrEmpty(userinput.Text))
            {
                userinput.Text = "Enter Hash to ID Here..";
                userinput.ForeColor = Color.Gray;
            }
        }

        private void userinput_Click(object sender, EventArgs e)// function to clear placeholder upon user clicking it
        {

            if (userinput.Text == "Enter Hash to ID Here..")
            {
                userinput.Text = "";
            }
        }

        private void Clear_Button_Click(object sender, EventArgs e)// function to clear results from text box
        {
            userinput.Text = "";
        }
    }
}
